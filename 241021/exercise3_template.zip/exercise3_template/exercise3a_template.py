class Beverage:
    def cost(self):
        return 0

    def description(self):
        return "beverage"

class Decorator(Beverage):
    def __init__(self, beverage):
        self.beverage = beverage

    def cost(self):
        return self.beverage.cost()

    def description(self):
        return self.beverage.description()

# The above is a fixed class, please do not modify it.
# Please complete other classes here >>

# << Please complete other classes here
# The following are the test cases, please do not modify them

beverages = [
    GreenTea(),
    Milk(Milk(BlackTea())),
    Milk(Ice(GreenTea())),
    Bubble(Milk(Ice(BlackTea())))
]

for b in beverages:
    if isinstance(b, Beverage):
        print(b.description(), "is a beverage!")
    else:
        print(b.description(), "is not a beverage?")
    print("Its price is", b.cost())

'''
Output:
greenTea is a beverage!
Its price is 20
blackTea + milk + milk is a beverage!
Its price is 35
greenTea + ice + milk is a beverage!
Its price is 26
blackTea + ice + milk + bubble is a beverage!
Its price is 41
'''
