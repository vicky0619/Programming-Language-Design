public abstract class Exp {
    public abstract Boolean eval();
    public abstract String toSExp();
}
