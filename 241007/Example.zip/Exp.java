public abstract class Exp {
	public abstract int eval();
}